package com.dicoding.storyapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.paging.PagingData
import com.dicoding.storyapp.model.Story
import com.dicoding.storyapp.model.StoryRepository

class HomeViewModel(private val repo: StoryRepository) : ViewModel() {

    val story: LiveData<PagingData<Story>> =
        repo.getStoryData()
}